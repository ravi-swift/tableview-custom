//
//  ViewController.swift
//  tblCustom
//
//  Created by Rp on 25/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var tblview : UITableView!
    
        var arrayOne = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    
    var array = NSMutableArray()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        array = NSMutableArray.init(array: arrayOne)
    
                tblview.tableFooterView = UIView()
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let lbl = cell.contentView.viewWithTag(1001) as! UILabel
        lbl.text = array.object(at: indexPath.row) as! String
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
    //
    //        if (editingStyle == .delete){
    //
    //            array.remove(at: indexPath.row)
    //            self.tblview.reloadData()
    //
    //        }
    //    }
    
    
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let deleteAction = UITableViewRowAction.init(style: .default, title: "Delete") { (action, indexpath) in
            
            self.array.remove(self.array.object(at: indexPath.row))
            self.tblview.reloadData()
        }
        
        let editAction = UITableViewRowAction.init(style: .default, title: "Edit") { (action, indexpath) in
            
            let alertControl = UIAlertController.init(title: "Add Changes", message: "", preferredStyle: .alert)
          
            alertControl.addTextField(configurationHandler: { (textfield) in
                textfield.placeholder = "Edit"
            })
            
            let  editAction = UIAlertAction.init(title: "Edit", style: .default, handler: { (alertAction) in
                
                let firstTextField = alertControl.textFields![0] as UITextField
                self.array.replaceObject(at: indexPath.row, with: firstTextField.text)

                self.tblview.reloadRows(at: [indexPath], with: .automatic)
            })
            
            let saveAction = UIAlertAction.init(title: "Add Title", style: .default, handler: { (alertAction) in
                let firstTextField = alertControl.textFields![0] as UITextField

                self.array.add(firstTextField.text)
                self.tblview.reloadData()
            })
            
            let cancleAction = UIAlertAction.init(title: "Cancle", style: .default, handler: { (alertaction) in
                
            })
            
            alertControl.addAction(editAction)
            alertControl.addAction(saveAction)
            alertControl.addAction(cancleAction)

            
            self.present(alertControl, animated: true, completion: nil)
        }
        
        
        return [deleteAction, editAction]
        
    }
    
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

